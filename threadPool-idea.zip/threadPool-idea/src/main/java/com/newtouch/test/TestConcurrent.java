package com.newtouch.test;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import com.newtouch.concurrentThread.service.TaskExecutor;
import com.newtouch.concurrentThread.task.Task;
import com.newtouch.concurrentThread.task.impls.PrintCurrentTimeTask;
public class TestConcurrent {
	/**
	 * 测试多线程框架（简单框架）
	 * @param args
	 */
	public static void main(String[] args) {
		// 这里还不能直接用实际类型声明 List<PrintCurrentTimeTask>，否则taskExecutor.executeTask(pool, taskList)会报错
		List<Task> taskList = new ArrayList<Task>();

		ExecutorService pool = TaskExecutor.getPool();
		TaskExecutor taskExecutor = new TaskExecutor();
		taskExecutor.executeTask(pool, taskList);

		int count = 0;
		PrintCurrentTimeTask task1 = new PrintCurrentTimeTask();
		task1.setParam("第"+(++count)+"次请求的参数");

		PrintCurrentTimeTask task2 = new PrintCurrentTimeTask();
		task2.setParam("第"+(++count)+"次请求的参数");

		PrintCurrentTimeTask task3 = new PrintCurrentTimeTask();
		task3.setParam("第"+(++count)+"次请求的参数");

		taskList.clear();// 清空，模拟并发3次新http请求
		taskList.add(task1);
		taskList.add(task2);
		taskList.add(task3);
		while (true) {
			try {
				Thread.sleep(1*1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println();
			taskExecutor.executeTask(pool, taskList);
		}
	}
}
