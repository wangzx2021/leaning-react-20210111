package com.newtouch.concurrentThread.task;

public interface ITask {
	public Object dealTrans();
}
