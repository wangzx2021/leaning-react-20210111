package com.newtouch.concurrentThread.impls;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 	线程工厂实现类：
 *  【按需】创建新线程的对象。使用线程工厂
 *	移除对{@link Thread#Thread（Runnable）new Thread}的调用的【硬连线】，
 *	使应用程序能够使用【特殊的线程子类】、优先级等。
 *  @author lenovo
 */
public class ThreadFactoryImpl implements ThreadFactory {

	// final修饰的【实例成员变量】只能在声明时或构造方法里初始化，而【类成员变量（前面再加一个static）】另外可以在静态代码块里初始化，【只能初始化一次】。
	final ThreadGroup threadGroup;
	
	private String threadName;
	// 递增计数器（英文 automatic 自动 ）
	final AtomicInteger atomicInteger = new AtomicInteger(1);
	
	public ThreadFactoryImpl(String taskName) {
		// 自动提示：The blank final field threadGroup may not have been initialized
		SecurityManager securityManager = System.getSecurityManager();
		threadGroup = securityManager != null ? securityManager.getThreadGroup() : Thread.currentThread().getThreadGroup();
		threadName = taskName;
	}

	public Thread newThread(Runnable r) {
		// System.out.println(atomicInteger.get());
		Thread thread = new Thread(threadGroup, r, threadName+atomicInteger.getAndIncrement(), 0);
		// daemon 守护进程，运行在后台的一种特殊进程。它独立于控制终端并且周期性地执行某种任务或等待处理某些发生的事件。
		if(thread.isDaemon()){
			thread.setDaemon(false);
		}
		// normalised [ˈnɔːməlaɪzd] 标准的； priority[praɪˈɒrəti] 优先级
		// 标准优先级，另外还有最小、最大优先级选项可以设置
		if(thread.getPriority() != Thread.NORM_PRIORITY){
			thread.setPriority(Thread.NORM_PRIORITY);
		}
		return thread;
	}

}
