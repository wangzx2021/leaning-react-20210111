package com.newtouch.concurrentThread.task.impls;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.newtouch.concurrentThread.task.Task;

public class PrintCurrentTimeTask extends Task {

    private ThreadLocal<String> threadLocal;

    public Object dealTrans() {
        if (threadLocal == null) {
            threadLocal = new ThreadLocal<String>();
        }
        System.out.println("当前线程号【"+Thread.currentThread().getId()+"】 threadLocal【" + threadLocal.get()+"】 任务参数：【" + getParam() + "】任务描述：【" + getDesc() + "】" + (new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")).format(new Date()));
        threadLocal.set((String)getParam());
        return null;
    }

    @Override
    public String getDesc() {
        return "模拟http请求";
    }

    public Object call() throws Exception {
        Object o = dealTrans();
        return o;
    }

}
