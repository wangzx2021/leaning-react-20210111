package com.newtouch.concurrentThread.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import com.newtouch.concurrentThread.impls.ThreadFactoryImpl;
import com.newtouch.concurrentThread.task.Task;

/**
 * 任务执行器
 * @author "汪志雄"
 */
public class TaskExecutor {
	// 默认的线程池名
	public static final String NO_TASK_NAME = "no_task_name";
	// 线程池缓存
	public static Map<String, ExecutorService> poolMap = new HashMap<String, ExecutorService>();
	public static ExecutorService getPool() {
		return getPool(NO_TASK_NAME);
	}
	public static ExecutorService getPool(String taskName) {
		// 默认线程池里的任务并发数=5个
//		return getPool(taskName,2);
		return getPool(taskName,2);
	}
	public static ExecutorService getPool(String taskName, int threadNum) {
		// 这里需要使用同步代码块吗？
		synchronized(TaskExecutor.class){
			if(poolMap.get(taskName) != null){
				return poolMap.get(taskName);
			}else{
				ThreadFactory threadFactory = new ThreadFactoryImpl(taskName);
//				Java通过Executors提供四种线程池，分别为：
//				newCachedThreadPool创建一个可缓存线程池，如果线程池长度超过处理需要，可灵活回收空闲线程，若无可回收，则新建线程。
//				newFixedThreadPool 创建一个定长线程池，可控制线程最大并发数，超出的线程会在队列中等待。
//				newScheduledThreadPool 创建一个定长线程池，支持定时及周期性任务执行。
//				newSingleThreadExecutor 创建一个单线程化的线程池，它只会用唯一的工作线程来执行任务，保证所有任务按照指定顺序(FIFO, LIFO, 优先级)执行。
				ExecutorService pool = Executors.newFixedThreadPool(threadNum, threadFactory);
				poolMap.put(taskName, pool);
				return pool;
			}
		}
	}
	public Object executeTask(ExecutorService pool,List<Task> taskList){
		// 这里加了个final，其实加不加无所谓
		for(Task task : taskList){
//			pool.submit(new Callable<Object>(){
//				@Override
//				public Object call() throws Exception {
//					Object o = task.dealTrans();
//					return o;
//				}
//			});
			// 直接在Task里实现Callable<Object>感觉更简单点，【即时】实现【父  类/接口】的写法也得记一下
			pool.submit(task);
		}
		return null;
	}
}
