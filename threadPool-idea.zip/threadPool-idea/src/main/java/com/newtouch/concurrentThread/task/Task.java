package com.newtouch.concurrentThread.task;

import java.util.concurrent.Callable;

/**
 * @author "汪志雄"
 */
public abstract class Task implements ITask,Callable<Object> {

	// 子类是抽象类的话，可以不实现父接口的方法dealTrans，实体类则必须实现

	// 任务描述
	public abstract String getDesc();

	public Object param;

	public Object getParam() {
		return param;
	}

	public void setParam(Object param) {
		this.param = param;
	}
}
